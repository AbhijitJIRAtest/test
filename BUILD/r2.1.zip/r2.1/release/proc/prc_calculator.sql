create or replace PROCEDURE prc_calculator 
( p_i_val_1 IN NUMBER
,p_i_val_2 IN NUMBER
,p_i_operator IN VARCHAR2
,p_o_result OUT NUMBER )
IS
BEGIN

                DBMS_OUTPUT.PUT_LINE('p_i_operator values: SUM=> + Minus=> - Multiplication=> * Division=> /');
  
  IF p_i_operator = '+' THEN
   p_o_result := p_i_val_1+p_i_val_2;
  ELSIF p_i_operator = '-' THEN
   p_o_result := p_i_val_1-p_i_val_2;
  ELSIF p_i_operator = '*' THEN
   p_o_result := p_i_val_1*p_i_val_2;
  ELSIF p_i_operator = '/' THEN 
   p_o_result := p_i_val_1/p_i_val_2;
  ELSE 
   DBMS_OUTPUT.PUT_LINE('Invalid Operator: '||p_i_operator); 
  END IF;

EXCEPTION  
WHEN OTHERS THEN
RAISE_APPLICATION_ERROR(-20001,'Error Details: '||TO_CHAR(SQLCODE)||SQLERRM);  
END prc_calculator;