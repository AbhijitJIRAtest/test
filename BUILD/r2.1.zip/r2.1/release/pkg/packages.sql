prompt --pkg_reports_spec.sql
@./release/pkg/pkg_reports_spec.sql
prompt --pkg_reports_body.sql
@./release/pkg/pkg_reports_body.sql
prompt --pkg_integration_spec.sql
@./release/pkg/pkg_integration_spec.sql
prompt --pkg_integration_body.sql
@./release/pkg/pkg_integration_body.sql
prompt --pkg_audit_spec.sql
@./release/pkg/pkg_audit_spec.sql
prompt --pkg_audit_body.sql
@./release/pkg/pkg_audit_body.sql
prompt --pkg_potent_inv_spec.sql
@./release/pkg/pkg_potent_inv_spec.sql
prompt --pkg_potent_inv_body.sql
@./release/pkg/pkg_potent_inv_body.sql
prompt --pkg_user_deactivation_spec.sql
@./release/pkg/pkg_user_deactivation_spec.sql
prompt --pkg_user_deactivation_body.sql
@./release/pkg/pkg_user_deactivation_body.sql
prompt --pkg_study_site_spec.sql
@./release/pkg/pkg_study_site_spec.sql
prompt --pkg_study_site_body.sql
@./release/pkg/pkg_study_site_body.sql
prompt --pkg_study_site_closure_spec.sql
@./release/pkg/pkg_study_site_closure_spec.sql
prompt --pkg_study_site_closure_body.sql
@./release/pkg/pkg_study_site_closure_body.sql
prompt --pkg_integ_spec.sql
@./release/pkg/pkg_integ_spec.sql
prompt --pkg_integ_body.sql
@./release/pkg/pkg_integ_body.sql
prompt --pkg_doc_exchange_spec.sql
@./release/pkg/pkg_doc_exchange_spec.sql
prompt --pkg_doc_exchange_body.sql
@./release/pkg/pkg_doc_exchange_body.sql
prompt --pkg_doc_exchange_spec.sql
@./release/pkg/pkg_search_spec.sql
prompt --pkg_doc_exchange_body.sql
@./release/pkg/pkg_search_body.sql