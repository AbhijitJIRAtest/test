prompt --TBL_SURVEYMETADATA.sql
@./release/dml/TBL_SURVEYMETADATA.sql
prompt --TBL_SURVEYMETADATATYPE.sql
@./release/dml/TBL_SURVEYMETADATATYPE.sql
prompt --tbl_encryptioncolumn.sql
@./release/dml/tbl_encryptioncolumn.sql
prompt --tbl_roletype.sql
@./release/dml/tbl_roletype.sql
prompt --tbl_roles.sql
@./release/dml/tbl_roles.sql
prompt --tbl_sponsor_businessunit.sql
@./release/dml/tbl_sponsor_businessunit.sql
prompt --tbl_template.sql
@./release/dml/tbl_template.sql
prompt --tbl_labaccreditation.sql
@./release/dml/tbl_labaccreditation.sql
prompt --TBL_TASKTYPES.sql
@./release/dml/TBL_TASKTYPES.sql
prompt --tbl_columnfieldmap.sql
@./release/dml/tbl_columnfieldmap.sql
prompt --TBL_SITESECTIONS.sql
@./release/dml/TBL_SITESECTIONS.sql
prompt --TBL_STUDYSECTIONS.sql
@./release/dml/TBL_STUDYSECTIONS.sql
prompt --TBL_ALERTANDNOTIFICATIONTYPE.sql
@./release/dml/TBL_ALERTANDNOTIFICATIONTYPE.sql
prompt --tbl_justification.sql
@./release/dml/tbl_justification.sql
prompt --TBL_TASKCATEGORY.sql
@./release/dml/TBL_TASKCATEGORY.sql
prompt --tbl_trainingtype.sql
@./release/dml/tbl_trainingtype.sql
prompt --tbl_packagesubmission.sql
@./release/dml/tbl_packagesubmission.sql
prompt --tbl_code.sql
@./release/dml/tbl_code.sql