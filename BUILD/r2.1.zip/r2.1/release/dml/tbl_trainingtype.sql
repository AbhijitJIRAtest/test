UPDATE tbl_trainingtype set TRAININGTYPENAME='SIP Training' where TRAININGTYPENAME='Pre-requisite';
COMMIT;
