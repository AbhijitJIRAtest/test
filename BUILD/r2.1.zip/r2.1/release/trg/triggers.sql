prompt -- TRG_TBL_FUTSPNSRONBRDING_ENCRY.sql
@./release/trg/TRG_TBL_FUTSPNSRONBRDING_ENCRY.sql
prompt -- TRG_TBL_SURVEY_AUDIT.sql
@./release/trg/TRG_TBL_SURVEY_AUDIT.sql
prompt -- TRG_TBL_SIPASSOCIATION_AUDIT.sql
@./release/trg/TRG_TBL_SIPASSOCIATION_AUDIT.sql
prompt -- TRG_TBL_SURVEY_PROGMAP_AUDIT.sql
@./release/trg/TRG_TBL_SURVEY_PROGMAP_AUDIT.sql
prompt -- TRG_TBL_SURVEYSECTION_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYSECTION_AUDIT.sql
prompt -- TRG_TBL_SURVEYANSWER_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYANSWER_AUDIT.sql
prompt -- TRG_TBL_SURVEYLOGICJUMP_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYLOGICJUMP_AUDIT.sql
prompt -- TRG_TBL_SURVEYTEMPLATE_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYTEMPLATE_AUDIT.sql
prompt -- TRG_TBL_USERROLEMAP_AUDIT.sql
@./release/trg/TRG_TBL_USERROLEMAP_AUDIT.sql
prompt -- TRG_TBL_COMPDELMAP_AUDIT.sql
@./release/trg/TRG_TBL_COMPDELMAP_AUDIT.sql
prompt -- trg_tbl_responsemngrmap_audit.sql
@./release/trg/trg_tbl_responsemngrmap_audit.sql
prompt -- TRG_TBL_SURVEYRSPNSWR_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYRSPNSWR_AUDIT.sql
prompt -- TRG_TBL_STUDY_AUDIT.sql
@./release/trg/TRG_TBL_STUDY_AUDIT.sql
prompt -- trg_tbl_studycntrymstone_audit.sql
@./release/trg/trg_tbl_studycntrymstone_audit.sql
prompt -- TRG_TBL_STUDYCENTRALIRB_AUDIT.sql
@./release/trg/TRG_TBL_STUDYCENTRALIRB_AUDIT.sql
prompt -- TRG_TBL_STUDYCENTRALLAB_AUDIT.sql
@./release/trg/TRG_TBL_STUDYCENTRALLAB_AUDIT.sql
prompt -- TRG_TBL_POTINVESTIGATOR_AUDIT.sql
@./release/trg/TRG_TBL_POTINVESTIGATOR_AUDIT.sql
prompt -- trg_tbl_studysystem_unique.sql
@./release/trg/trg_tbl_studysystem_unique.sql
prompt -- TRG_TBL_SITEIRBMAP_AUDIT.sql
@./release/trg/TRG_TBL_SITEIRBMAP_AUDIT.sql
prompt -- TRG_TBL_SITELABMAP_AUDIT.sql
@./release/trg/TRG_TBL_SITELABMAP_AUDIT.sql
prompt -- TRG_TBL_SITELABACCRED_AUDIT.sql
@./release/trg/TRG_TBL_SITELABACCRED_AUDIT.sql
prompt -- trg_tbl_studycontacts_unique.sql
@./release/trg/trg_tbl_studycontacts_unique.sql
prompt -- TRG_TBL_STUDYSYSTEMMAP_AUDIT.sql
@./release/trg/TRG_TBL_STUDYSYSTEMMAP_AUDIT.sql
prompt -- TRG_TBL_SITESYSTEMACCESS_AUDIT.sql
@./release/trg/TRG_TBL_SITESYSTEMACCESS_AUDIT.sql
prompt -- TRG_TBL_SITEIRBREG_AUDIT.sql
@./release/trg/TRG_TBL_SITEIRBREG_AUDIT.sql
prompt -- TRG_TBL_STUDYLABCOUNTRY_AUDIT.sql
@./release/trg/TRG_TBL_STUDYLABCOUNTRY_AUDIT.sql
prompt -- TRG_TBL_STUDYTHERAAREA_AUDIT.sql
@./release/trg/TRG_TBL_STUDYTHERAAREA_AUDIT.sql
prompt -- TRG_TBL_STUDYINDICATION_AUDIT.sql
@./release/trg/TRG_TBL_STUDYINDICATION_AUDIT.sql
prompt -- TRG_TBL_DOCUMENTS_AUDIT.sql
@./release/trg/TRG_TBL_DOCUMENTS_AUDIT.sql
prompt -- trg_tbl_facilities_unique.sql
@./release/trg/trg_tbl_facilities_unique.sql
prompt -- trg_tbl_sitecontact_unique.sql
@./release/trg/trg_tbl_sitecontact_unique.sql
prompt -- TRG_TBL_SURVEYUSERMAP_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYUSERMAP_AUDIT.sql
prompt -- trg_tbl_recipientlist_audit.sql
@./release/trg/trg_tbl_recipientlist_audit.sql 
prompt -- TRG_TBL_SURVEYRESPONSE_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYRESPONSE_AUDIT.sql 
prompt -- TRG_TBL_POTINVFACMAP_AUDIT.sql
@./release/trg/TRG_TBL_POTINVFACMAP_AUDIT.sql 
prompt -- trg_tbl_orgsystemaccess_unique.sql
@./release/trg/trg_tbl_orgsystemaccess_unique.sql 
prompt --TRG_TBL_SITECONTACTMAP_AUDIT.sql
@./release/trg/TRG_TBL_SITECONTACTMAP_AUDIT.sql
prompt --TRG_TBL_CONTACT_AUDIT.sql
@./release/trg/TRG_TBL_CONTACT_AUDIT.sql
prompt --TRG_TBL_STUDYSECSTATUS_AUDIT.sql
@./release/trg/TRG_TBL_STUDYSECSTATUS_AUDIT.sql
prompt --TRG_TBL_SITESECSTATUS_AUDIT.sql
@./release/trg/TRG_TBL_SITESECSTATUS_AUDIT.sql
prompt --TRG_TBL_ADDLSITELOCATION_AUDIT.sql
@./release/trg/TRG_TBL_ADDLSITELOCATION_AUDIT.sql
prompt --trg_tbl_site_audit.sql
@./release/trg/trg_tbl_site_audit.sql
prompt --TRG_TBL_SURVEYRESPONLIST_AUDIT.sql
@./release/trg/TRG_TBL_SURVEYRESPONLIST_AUDIT.sql